# 구조

- service: <service-name>
- interface: <REST 또는 MCP>
- database: <member-owned DB 또는 none>
- flow: client -> service -> database
- 외부 의존성: <목록과 사용 이유>
- loopback port: <관리자가 지정한 포트 또는 미정>
