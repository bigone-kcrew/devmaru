# 운영

```text
build:  ai-project-build <user> <project>
start:  ai-project-up <user> <project>
status: ai-project-status <user> <project>
logs:   ai-project-logs <user> <project>
stop:   ai-project-down <user> <project>
```

- health: <명령 또는 URL>
- backup/restore: <방법 또는 미정>
- 자원: CPU <값>, RAM <값>, PID <값>, disk <값>
- 장애 시 연락: 관리자에게 결과와 마지막 로그 요약을 전달
