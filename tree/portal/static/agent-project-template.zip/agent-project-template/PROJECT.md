# <프로젝트명>

- owner: <member>
- 목적: <한 문장으로 설명>
- 사용자: <member 또는 내부 사용자>
- 데이터 분류: <public/internal/sensitive>
- 외부 공개: <no 또는 관리자 승인 경로>
