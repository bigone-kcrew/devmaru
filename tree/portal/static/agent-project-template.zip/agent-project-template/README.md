# AI Club Agent 프로젝트 템플릿

이 디렉터리는 멤버 프로젝트 제출 패키지의 최소 예시다.

1. `<...>` placeholder를 실제 값으로 바꾼다.
2. secret, API key, password, private key는 코드·문서·git에 넣지 않는다. 멤버 소유 `.env`(`umask 077`·`chmod 600`·`.gitignore`)에는 이 프로젝트 전용이고 Agent에게 보여도 되는 값만 둘 수 있고, `.env.example`에는 변수명만 둔다. `.dockerignore`가 `.env`를 이미지 빌드 컨텍스트에서 제외한다.
3. DB 비밀번호는 `.env`를 포함해 어떤 파일에도 두지 않는다. `PGPASSWORD` 환경변수 또는 `~/.pgpass`(`chmod 600`)만 쓴다.
4. 외부 공개가 필요 없으면 `deploy/caddy-request.yaml`을 삭제한다. 필요하면 실제 값으로 바꾼 뒤 `ai-caddy-request validate deploy/caddy-request.yaml`로 형식을 확인한다.
5. 서비스 등록이 필요 없으면 `deploy/service-request.yaml`을 삭제한다. 컨테이너만·DB만·RAG만·내부 작업만 하는 프로젝트에는 필요 없다.
6. 관리자에게 부탁할 일이 있으면 `REQUEST/README.md` 양식대로 요청 문서를 만든다. 부탁할 일이 없으면 `REQUEST/`를 삭제한다.
7. 제출 전에 `PROJECT.md`, `ARCHITECTURE.md`, `OPERATIONS.md`와 compose diff를 검토한다.

이 샘플은 실행 가능한 서비스가 아니라 문서·구조 예시다.
