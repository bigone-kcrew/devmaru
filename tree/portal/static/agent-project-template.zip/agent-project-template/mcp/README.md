# MCP 예시

- transport: <stdio 또는 HTTP>
- tools: <tool 목록>
- auth: <내부 또는 관리자 승인 Bearer>
- input/output: <각 tool의 예시>
- errors: <401/403/429/5xx 처리>
