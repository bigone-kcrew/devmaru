# RAG 예시

- source: <원천 데이터와 소유자>
- ingestion: <수집·정제 방법>
- schema: <테이블·필드·metadata>
- index/rebuild: <재색인 명령과 소요 시간>
- freshness: <갱신 주기>
- deletion: <삭제·보존 정책>
